import React from 'react'
import "./Category.css"

function Category() {
  return (
    <div className='category container2'>
       <h2>Category</h2>
    </div>
  )
}

export default Category
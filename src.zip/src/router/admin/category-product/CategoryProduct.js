import React from 'react'
import Home from '../../home/Home'
import "./CategoryProduct.css"
function CategoryProduct() {

  return (
    <div className='category'>
        <Home admin={true}/>
    </div>
  )
}

export default CategoryProduct
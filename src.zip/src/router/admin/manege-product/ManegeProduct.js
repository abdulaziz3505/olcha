import React from 'react'
import Products from "../../../components/products/Products"

function MenegeProduct() {
  return (
    <div>
        <h2>MenegeProduct</h2>
        <Products admin={true}/>
    </div>
  )
}

export default MenegeProduct